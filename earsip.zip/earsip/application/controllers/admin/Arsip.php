<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Arsip extends CI_Controller
{
   function __construct()
    {
        parent::__construct();
       $this->load->library('form_validation');
       $this->load->model('m_arsip');
       $this->load->model('m_lemari');
       $this->load->model('m_rak');
       $this->load->model('m_kategori');
        $this->load->library('session');
        is_login();
    }

 

public function index()
    {
        $data["lemari"] = $this->m_lemari->getAll();
        $data["arsip"] = $this->m_arsip->getAll();
        $data["rak"] = $this->m_rak->getAll();
        $data["kategori"] = $this->m_kategori->getAll();
        $this->load->view("admin/arsip/list", $data);
    }
    public function add()
  {
        $arsip = $this->m_arsip;

        $data["lemari"] = $this->m_lemari->getAll();
         $data["rak"] = $this->m_rak->getAll();
          $data["kategori"] = $this->m_kategori->getAll();

        
    $this->form_validation->set_rules('nama_file','Nama','required|trim');
     $this->form_validation->set_rules('judul','Judul','required|trim');
      $this->form_validation->set_rules('deskripsi','Deskripsi','required|trim');
       $this->load->view('admin/arsip/new_form',$data);
     
       
          
  }

   public function aksi_tambah(){
       
        //image
        ini_set('max_execution_time', 1000);
        $filename = $this->judul;
        $config['upload_path']   = './upload/';
        $config['allowed_types'] = 'pdf|docx';
        $config['encrypt_name'] = TRUE; //mengatasi nama yang sama
         

        if (!file_exists($config['upload_path'])) {
            mkdir($config['upload_path'], 0777, true);
        }

        $this->load->library('upload', $config);

                if ($this->upload->do_upload('nama_file') || empty($_FILES['nama_file']['name'])) {
                    if (!empty($_FILES['nama_file']['name'])) {
                        $upload = $this->upload->data();
                        $filename = '/upload/' .$upload['file_name'];
                    }
                    $data = array(
                       
                          'nama_file'=>$filename,
                          'judul'=>$this->input->post('judul'),
                          'deskripsi'=>$this->input->post('deskripsi'),
                          'tgl_upload'=>date('Y-m-d'),
                          'kode_lemari'=>$this->input->post('kode_lemari'),
                          'kode_rak'=>$this->input->post('kode_rak'),
                          'kode'=>$this->input->post('kode'),
                          'tgl_dokumen' => $this->input->post('tgl_dokumen'),
                    );

                    $add = $this->db->insert('arsip_dokumen', $data);
                    if($add) {
                        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">data berhasil ditambah</div>');
                         redirect('admin/arsip');
                    }else{
                       $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">data gagal ditambah</div>');
                             redirect('admin/arsip');
                    }

        }
               
        
    }

 public function edit($id)
    {
        $arsip = $this->m_arsip->getAll2($id);
        $lemari = $this->m_lemari->getAll();
        $rak = $this->m_rak->getAll();
        $kategori = $this->m_kategori->getAll();

        $validation = $this->form_validation;

        if ($validation->run()) {
            $arsip->save();
            $this->session->set_flashdata('success', 'Berhasil disimpan');
        }

        $data = array('arsip' => $arsip,
                        'lemari'  => $lemari,
                      'rak'  => $rak,
                      'kategori'  => $kategori);

        $this->load->view("admin/arsip/edit", $data);
    }

    function edit_dokumen(){

        $id = $this->input->post('id');
        $nama_file = $this->input->post('nama_file');
        $judul = $this->input->post('judul');
        $deskripsi = $this->input->post('deskripsi');
        $tgl_dokumen = $this->input->post('tgl_dokumen');
        $kode_lemari = $this->input->post('kode_lemari');
        $kode_rak = $this->input->post('kode_rak');
        $kode = $this->input->post('kode');
       

        $data = array(
            'nama_file' => $nama_file,
            'judul' => $judul,
            'deskripsi' => $deskripsi,
            'tgl_dokumen' => $tgl_dokumen,
            'kode_lemari' => $kode_lemari,
            'kode_rak' => $kode_rak,
            'kode' => $kode,
           
        );
        //$add = $this->pekerjaan_model->add('$data')

        $edit = $this->db->update('arsip_dokumen',$data, array('id' => $id));
        //$edit = $this->pekerjaan_model->edit($data);
        if($edit){
            redirect('admin/arsip');
         }else{
            redirect('admin/arsip');
         }
          $this->session->set_flashdata('success', 'Berhasil disimpan');

    }

 
  public function download($id)
  {
    $data = $this->db->get_where('arsip_dokumen',['id'=>$id])->row();
    force_download('upload/'.$data->nama_file,"nama_file");
  }


 public function hapus($id)

    {

        $data = array ('id' => $id);

        $this->m_arsip->hapus_data($data, 'arsip_dokumen');

        redirect ('admin/arsip');
    }
}
  

