<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Kategori extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model("m_kategori");
        $this->load->library('form_validation');
         $this->load->library('session');
       is_login();
    }

  public function index()
    {
        $data["kategori"] = $this->m_kategori->tampil_data()->result();
        $this->load->view("admin/kategori/list", $data);
    }


  public function aksi_tambah()
 {
      $this->form_validation->set_rules('kode','Kode','required|trim|is_unique[kategori.kode]',[
            'is_unique' => 'Id Sudah Terdaftar'

              ]);
      $this->form_validation->set_rules('nama_k','Nama','required|trim');


      if ($this->form_validation->run() == false){

                  $data['title'] = 'Arsip Ezra Pratama';
                  $this->load->view("admin/kategori/new_form", $data);
                 
      } else{
        $data = [
              'kode' => $this->input->post('kode', true),
               'nama_k' => $this->input->post('nama_k', true),
               
          ];

          $this->db->insert('kategori',$data);
        $this->session->set_flashdata('message','<div class="alert alert-success " role="alert">Kategori Berhasil ditambahkan
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button></div>');
          redirect('admin/kategori');
       
    }
  }

public function hapus($kode)

    {

        $data = array ('kode' => $kode);

        $this->m_kategori->hapus_data($data, 'kategori');

        redirect ('admin/kategori');
    }
      public function edit($kode){
        $where = array('kode' =>$kode);
        $data['kategori'] = $this->m_kategori->edit_data($where,'kategori')->result();

        $this->load->view('admin/kategori/edit',$data);
      }
      public function edit_aksi(){
        $kode = $this->input->post('kode');
        $nama_k = $this->input->post('nama_k');
      $data = array(
      'kode' => $kode,
      'nama_k' => $nama_k,
      );
      $where = array(
      'kode' => $kode
      );
      $this->m_lemari->update_data($where,$data,'kategori');
       $this->session->set_flashdata('message','<div class="alert alert-success " role="alert">Kategori Berhasil diubah
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button></div>');
      redirect ('admin/kategori');
      }
               
        
    }
  

