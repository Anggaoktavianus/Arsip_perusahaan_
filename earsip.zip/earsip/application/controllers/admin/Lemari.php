<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Lemari extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("m_lemari");
        $this->load->library('form_validation');
       is_login();
    }

    public function index()
    {
        $data["lemari"] = $this->m_lemari->tampil_data()->result();
        $this->load->view("admin/lemari/list", $data);
    }
 
     public function tambah_aksi()
 {
      $this->form_validation->set_rules('kode_lemari','Kode','required|trim|is_unique[lemari.kode_lemari]',[
            'is_unique' => 'Id Sudah Terdaftar'

              ]);
      $this->form_validation->set_rules('nama','Nama','required|trim');


      if ($this->form_validation->run() == false){

                  $data['title'] = 'Arsip Ezra Pratama';
                  $this->load->view("admin/lemari/new_form", $data);
                 
      } else{
        $data = [
              'kode_lemari' => $this->input->post('kode_lemari', true),
               'nama' => $this->input->post('nama', true),
               
          ];

          $this->db->insert('lemari',$data);
          $this->session->set_flashdata('message','<div class="alert alert-success " role="alert">data berhasil ditambah
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button></div>');
          redirect('admin/lemari');
       
    }
  }
public function hapus($kode_lemari)

    {

        $data = array ('kode_lemari' => $kode_lemari);

        $this->m_lemari->hapus_data($data, 'lemari');

        redirect ('admin/lemari');
    }
public function edit($kode_lemari){
  $where = array('kode_lemari' =>$kode_lemari);
  $data['lemari'] = $this->m_lemari->edit_data($where,'lemari')->result();
  $this->load->view('admin/lemari/edit',$data);
}
public function edit_aksi(){
  $kode_lemari = $this->input->post('kode_lemari');
  $nama = $this->input->post('nama');
  $data = array(
          'kode_lemari' => $kode_lemari,
          'nama' => $nama,
          );
        $where = array(
        'kode_lemari' => $kode_lemari
        );
    $this->m_lemari->update_data($where,$data,'lemari');
    redirect ('admin/lemari');
    }
}