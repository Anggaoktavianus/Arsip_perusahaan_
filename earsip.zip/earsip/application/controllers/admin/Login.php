<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
  public function __construct()
  
  {
    parent:: __construct();
    $this->load->library('form_validation');
     $this->load->library('session');
  }

  public function index()
  {
    $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
    $this->form_validation->set_rules('password', 'Passsword', 'trim|required' );
      $data["users"] = $this->db->get_where('users', ['email' => $this->session->userdata('email')])->row_array();

    if ($this->form_validation->run() == false){
      $this->load->view('admin/login_page');
    }else{
      $this->_login();
    }
  }
  private function _login()
  {
    $email = $this->input->post('email');
    $password = $this->input->post('password');

    $user= $this->db->get_where('users',['email' => $email])->row_array();
     if($user){

       if($user ['is_active'] == 1){

        if(password_verify($password, $user['password'])){
          $data = [
            'email' => $user['email'],
            'role_id' =>$user['role_id']
          ];
          $this->session->set_flashdata($data);
          
          if ($user['role_id'] == 1 ){
            $this->session->set_userdata('emails', $user['email']);
          
            redirect('admin');
          }else{
            $this->session->set_userdata('emails', $user['email']);
          
            redirect('pengguna/dashboard');
          }
          
        }else{
          $this->session->set_flashdata('message','<div class="alert alert-danger " role="alert">Gagal, Akun Belum Terdaftar
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button></div>');
          redirect('admin/login');
        }

       }else{
        $this->session->set_flashdata('message','<div class="alert alert-danger " role="alert">Gagal, Passsword atau email salah
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button></div>');
                  redirect('admin/login');
       }

     }else{
      $this->session->set_flashdata('message','<div class="alert alert-danger " role="alert">Gagal, Passsword atau email salah
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button></div>');
      redirect('admin/login');
     }
   }
   public function logout()
   {
   $this->session->sess_destroy();
   redirect('admin/login');
  }
}
