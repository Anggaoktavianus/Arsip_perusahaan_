<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Master extends CI_Controller
{
    public function __construct()
    {

        parent::__construct();
        $this->load->model("m_master");
        $this->load->library('form_validation');
        $this->load->library('session');
        is_login();
    }

    public function index()
    {
        
        $data["master"] = $this->m_master->getAll();
        $this->load->view("admin/master/list", $data);
    }

   public function edit($user_id){
        $where = array('user_id' =>$user_id);
        $data['master'] = $this->m_master->edit_data($where,'users')->result();

        $this->load->view('admin/master/reset',$data);
      }
      public function edit_aksi(){
        $user_id = $this->input->post('user_id');
        $email = $this->input->post('email');
        $username = $this->input->post('username');
        $password = password_hash($this->input->post('password'),PASSWORD_DEFAULT);
      $data = array(
      'user_id' => $user_id,
      'email' => $email,
      'username' => $username,
      'password' => $password,
      );
      $where = array(
      'user_id' => $user_id
      );
      $this->m_master->update_data($where,$data,'users');
       $this->session->set_flashdata('message','<div class="alert alert-success " role="alert">Kategori Berhasil diubah
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button></div>');
      redirect ('admin/master');
      }
    
    
  
   public function tambah_aksi()
    {
        
      $this->form_validation->set_rules('username','Username','required|trim');
      $this->form_validation->set_rules('email','Email','required|trim','valid_email|is_unique[users.email]',[
            'is_unique' => 'Email Sudah Terdaftar'

              ]);
       $this->form_validation->set_rules('password','Password','required|trim');


      if ($this->form_validation->run() == false){

                  $data['title'] = 'Arsip Ezra Pratama';
                  $this->load->view("admin/master/new_form", $data);
                 
      } else{

        $email = $this->input->post('email', true);
        $cekemail = $this->db->query("SELECT COUNT(email) as hsl FROM users WHERE email = '$email'")->row();

        if($cekemail->hsl > 0){

        $this->session->set_flashdata('message','<div class="alert alert-danger " role="alert">Gagal, email sudah terdaftar
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button></div>');
        redirect('admin/master');
        
        }else{
        

        $data = [
              'username' => $this->input->post('username', true),
               'email' => $email,
               'password' => password_hash($this->input->post('password'),PASSWORD_DEFAULT),
               'role_id'=> $this->input->post('role_id'),
                'is_active'=> 1,
                'created_at' => time(),
          ];

          $this->db->insert('users',$data);
          $this->session->set_flashdata('message','<div class="alert alert-success " role="alert">data berhasil ditambah
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button></div>');
          redirect('admin/master');

        }
    }
  }
  public function hapus($user_id)

    {

        $data = array ('user_id' => $user_id);

        $this->m_master->hapus_data($data, 'users');

        redirect ('admin/master');
    }
}
  

