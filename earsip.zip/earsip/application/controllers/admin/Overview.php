<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Overview extends CI_Controller {

public function __construct()
    {

        parent::__construct();
        $this->load->model("m_master");
         $this->load->model("m_arsip");
          $this->load->model("m_kategori");
       $this->load->library('form_validation');
        $this->load->library('session');
    }

	public function index()
	{
        
        // load view admin/overview.php
         {
        $data["users"] = $this->db->get_where('users', ['email' => $this->session->userdata('email')])->row_array();
        $data_content['total_admin'] = $this->m_master->total_admin();
        $data_content['total_arsip'] = $this->m_arsip->total_arsip();
        $data_content['total_kategori'] = $this->m_kategori->total_kategori();
        
        $this->load->view("admin/overview", $data);
        $this->load->view("admin/partials/head");
        $this->load->view("admin/partials/sidebar");
        $this->load->view("admin/partials/page", $data_content);
        $this->load->view("admin/partials/js");
        
    }
  }

}
