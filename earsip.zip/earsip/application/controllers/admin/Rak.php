<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Rak extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("m_rak");
        $this->load->library('form_validation');
       
    }

    public function index()
    {
        $data["rak"] = $this->m_rak->tampil_data()->result();
        $this->load->view("admin/rak/list", $data);
    }
 
    public function tambah_aksi()
 {
      $this->form_validation->set_rules('kode_rak','Kode','required|trim|is_unique[rak.kode_rak]',[
            'is_unique' => 'Id Sudah Terdaftar'

              ]);
      $this->form_validation->set_rules('nama','Nama','required|trim');


      if ($this->form_validation->run() == false){

                  $data['title'] = 'Arsip Ezra Pratama';
                  $this->load->view("admin/rak/new_form", $data);
                 
      } else{
        $data = [
              'kode_rak' => $this->input->post('kode_rak', true),
               'nama' => $this->input->post('nama', true),
               
          ];

          $this->db->insert('rak',$data);
         $this->session->set_flashdata('message','<div class="alert alert-success " role="alert">data berhasil ditambah
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button></div>');
          redirect('admin/rak');
       
    }
  }
    public function hapus($kode_rak)

    {

        $data = array ('kode_rak' => $kode_rak);

        $this->m_rak->hapus_data($data, 'rak');

        redirect ('admin/rak');
    }

    public function edit($kode_rak){
      $where = array('kode_rak' =>$kode_rak);
      $data['rak'] = $this->m_rak->edit_data($where,'rak')->result();
      $this->load->view('admin/rak/edit',$data);
    }

    public function edit_aksi(){
      $kode_rak  = $this->input->post('kode_rak');
      $nama         = $this->input->post('nama');
        $data = array(
        'kode_rak' => $kode_rak,
        'nama'        => $nama,
        );
        $where = array(
        'kode_rak' => $kode_rak
        );

      $this->m_rak->update_data($where,$data,'rak');
      redirect ('admin/rak');
      }     
  }
  

