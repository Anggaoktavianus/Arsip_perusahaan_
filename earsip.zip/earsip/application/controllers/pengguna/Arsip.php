<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Arsip extends CI_Controller
{
    public function __construct()
    {

        parent::__construct();
        
       $this->load->library('form_validation');
       $this->load->model('m_arsip');
       $this->load->model('m_lemari');
       $this->load->model('m_rak');
       $this->load->model('m_kategori');
        $this->load->library('session');
    }

 

public function index()
    {
        $data["lemari"] = $this->m_lemari->getAll();
        $data["arsip"] = $this->m_arsip->getAll();
        $data["rak"] = $this->m_rak->getAll();
          $data["kategori"] = $this->m_kategori->getAll();
        $this->load->view("pengguna/list_arsip", $data);
    }
   

   
  function download($id)
  {
    $data = $this->db->get_where('arsip_dokumen',['id'=>$id])->row();
    force_download('upload/'.$data->nama_file,"nama_file");
  }

}
  

