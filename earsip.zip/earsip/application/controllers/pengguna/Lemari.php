<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Lemari extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("m_lemari");
        $this->load->library('form_validation');
       
    }

    public function index()
    {
        $data["lemari"] = $this->m_lemari->tampil_data()->result();
        $this->load->view("pengguna/list_lemari", $data);
    }
 
   
}