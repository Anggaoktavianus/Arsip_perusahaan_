<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Rak extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("m_rak");
        $this->load->library('form_validation');
       
    }

    public function index()
    {
        $data["rak"] = $this->m_rak->tampil_data()->result();
        $this->load->view("pengguna/list_rak", $data);
    }
 
       
  }
  

