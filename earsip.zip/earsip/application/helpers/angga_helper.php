<?php



function is_login(){
    $ci = get_instance();
    if($ci->session->userdata('emails') != null){
        return true;
    }else{
        
        redirect('admin/login');
    }
}

?>