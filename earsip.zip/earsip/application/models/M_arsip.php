<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_arsip extends CI_Model {

 
      public function getAll(){
          $this->db->select('arsip_dokumen.*, lemari.nama as namalemari, rak.nama as namarak, kategori.nama_k as namakategori');
          $this->db->from('arsip_dokumen');
          $this->db->join('lemari','arsip_dokumen.kode_lemari = lemari.kode_lemari','LEFT');      
          $this->db->join('rak','arsip_dokumen.kode_rak = rak.kode_rak','LEFT');
          $this->db->join('kategori','arsip_dokumen.kode = kategori.kode','LEFT');
          $query = $this->db->get();
          return $query;
       }

   public function getAll2($id)
    {
       $this->db->select('arsip_dokumen.*, lemari.nama as namalemari, rak.nama as namarak, kategori.nama_k as namakategori');
          $this->db->from('arsip_dokumen');
          $this->db->join('lemari','arsip_dokumen.kode_lemari = lemari.kode_lemari','LEFT');      
          $this->db->join('rak','arsip_dokumen.kode_rak = rak.kode_rak','LEFT');
          $this->db->join('kategori','arsip_dokumen.kode = kategori.kode','LEFT');
                 $this->db->where('arsip_dokumen.id',$id);
        $q = $this->db->get();
        return $q->row();
    }
   
   public function hapus_data($data){

        $this->db->delete('arsip_dokumen', $data);

    }
 public function getById($id)
    {
       $this->db->select('*');
        $this->db->from('arsip_dokumen');
        $this->db->where('id', $id);
        return $this->db->get();
    }
  public function add($data) {
         $xy = $this->db->insert('arsip_dokumen', $data);
         if($xy){
            return true;
         }else{
            return false;
         }

    }
 public function total_arsip() {
    $q=$this->db->query('SELECT COUNT(*) FROM arsip_dokumen');
    return $q->row_array()['COUNT(*)'];
  }

  public function edit_data($where,$table){
        return $this->db->get_where($table,$where);
    }
    public function update_data($where,$data,$table){
        $this->db->where($where);
        $this->db->update($table,$data);
    }
}
