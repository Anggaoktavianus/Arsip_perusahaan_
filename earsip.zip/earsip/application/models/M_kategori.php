<?php defined('BASEPATH') OR exit('No direct script access allowed');

class M_kategori extends CI_Model
{

   public function getAll()
    {
           $q=$this->db->select('*')->get('kategori');
        return $q->result();
    }
  public function tampil_data()
  {
    return $this->db->get('kategori');
  }
  public function input_data($data)
    {
        $this->db->insert('kategori', $data);
    }
   public function hapus_data($data){

        $this->db->delete('kategori', $data);

    }
    public function edit_data($where,$table){
        return $this->db->get_where($table,$where);
    }
    public function update_data($where,$data,$table){
        $this->db->where($where);
        $this->db->update($table,$data);
    }
    public function total_kategori() {
    $q=$this->db->query('SELECT COUNT(*) FROM kategori');
    return $q->row_array()['COUNT(*)'];
  }
}
