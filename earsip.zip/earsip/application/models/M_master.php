<?php defined('BASEPATH') OR exit('No direct script access allowed');

class M_master extends CI_Model
{

  public function getAll()
    {
           $q=$this->db->select('*')->get('users');
        return $q->result();
    }
   
    public function getById($id)
    {
       $this->db->select('*');
        $this->db->from('users');
        $this->db->where('user_id', $id);
        return $this->db->get();
    }
    
public function edit_data($where,$table){
        return $this->db->get_where($table,$where);
    }
    public function update_data($where,$data,$table){
        $this->db->where($where);
        $this->db->update($table,$data);
    }
     public function hapus_data($data){

        $this->db->delete('users', $data);

    }
  public function total_admin() {
    $q=$this->db->query('SELECT COUNT(*) FROM users');
    return $q->row_array()['COUNT(*)'];
  }

}
