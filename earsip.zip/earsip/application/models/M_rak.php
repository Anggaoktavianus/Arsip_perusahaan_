<?php defined('BASEPATH') OR exit('No direct script access allowed');

class M_rak extends CI_Model
{
public function getAll()
    {
           $q=$this->db->select('*')->get('rak');
        return $q->result();
    }
  public function tampil_data()
  {
    return $this->db->get('rak');
  }
  public function input_data($data)
    {
        $this->db->insert('rak', $data);
    }
   public function hapus_data($data){

        $this->db->delete('rak', $data);

    }
    public function edit_data($where,$table){
        return $this->db->get_where($table,$where);
    }
    public function update_data($where,$data,$table){
        $this->db->where($where);
        $this->db->update($table,$data);
    }
}
