<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- Basic -->
        <meta charset="UTF-8">
        <title>Edit Arsip</title>
        <meta name="keywords" content="HTML5 Admin Template" />
        <meta name="description" content="Porto Admin - Responsive HTML5 Template">
        <meta name="author" content="okler.net">
        <!-- Mobile Metas -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <!-- Web Fonts  -->
        <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">
        <!-- Vendor CSS -->
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/bootstrap/css/bootstrap.css')?>" />
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/font-awesome/css/font-awesome.css')?>" />
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/magnific-popup/magnific-popup.css')?>" />
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/bootstrap-datepicker/css/datepicker3.css')?>" />
        <!-- Specific Page Vendor CSS -->
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css')?>" />
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/select2/select2.css')?>" />
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css')?>" />
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/bootstrap-tagsinput/bootstrap-tagsinput.css')?>" />
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/bootstrap-colorpicker/css/bootstrap-colorpicker.css')?>" />
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/bootstrap-timepicker/css/bootstrap-timepicker.css')?>" />
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/dropzone/css/basic.css')?>" />
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/dropzone/css/dropzone.css')?>" />
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/bootstrap-markdown/css/bootstrap-markdown.min.css')?>" />
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/summernote/summernote.css')?>" />
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/summernote/summernote-bs3.css')?>" />
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/codemirror/lib/codemirror.css')?>" />
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/codemirror/theme/monokai.css')?>" />
 
        <!-- Theme CSS -->
        <link rel="stylesheet" href="<?php echo base_url('assets/stylesheets/theme.css')?>" />
        <!-- Skin CSS -->
        <link rel="stylesheet" href="<?php echo base_url('assets/stylesheets/skins/default.css')?>" />

        <!-- Theme Custom CSS -->
        <link rel="stylesheet" href="<?php echo base_url('assets/stylesheets/theme-custom.css')?>">

        <!-- Head Libs -->
        <script src="<?php echo base_url('assets/vendor/modernizr/modernizr.js')?>"></script>
    </head>
<body>
    <section class="body">
            <!-- start: header -->
            <?php $this->load->view("admin/partials/head.php") ?>
            <!-- end: header -->
            <div class="inner-wrapper">
                <!-- start: sidebar -->
                <?php $this->load->view("admin/partials/sidebar.php") ?>
                <!-- end: sidebar -->
                <!-- DataTables -->
                <section role="main" class="content-body">
                    <header class="page-header">
                        <h2>Data Arsip</h2>
                    
                        <div class="right-wrapper pull-right">
                            <ol class="breadcrumbs">
                                <li>
                                    <a href="<?php echo site_url('admin') ?>">
                                        <i class="fa fa-home"></i>
                                    </a>
                                </li>
                                <li><span>Dokumen</span></li>
                                <li><span>Edit</span></li>
                            </ol>
                            <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
                        </div>
                    </header>
                    <!-- start: page -->
                   <?=form_open('admin/arsip/edit_dokumen/', array('method'=>'post'));?>
                <input type="hidden" name="id" value="<?=$arsip->id;?>">
                       
                    <div class="row">
                        <div class="col-md-12">
                            <section class="panel">
                                <header class="panel-heading">
                                    <div class="panel-actions">
                                        <a href="#" class="fa fa-caret-down"></a>
                                        <a href="#" class="fa fa-times"></a>
                                    </div>
                                    <h2 class="panel-title">Form Edit</h2>
                                </header>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label class="control-label">Judul</label>
                                                <input type="text" name="judul" value="<?=$arsip->judul?>" class="form-control" />
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label class="control-label">Deskripsi</label>
                                                <input type="Text" name="deskripsi" value="<?=$arsip->deskripsi?>"  class="form-control" >
                                            </div>
                                        </div>
                                         <div class="col-sm-6">
                                            <div class="form-group">
                                                <label class="control-label">Nama File</label>
                                                <input type="file" name="nama_file" value="<?=$arsip->nama_file?>" class="form-control" />
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label class="control-label">Tanggal Dokumen</label>
                                                <input type="date" name="tgl_dokumen"  class="form-control" value="<?=$arsip->tgl_dokumen?>" >
                                            </div>
                                        </div> 
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label class="control-label">Lemari</label>
                                                <select name="kode_lemari" class="form-control">
                                                  <option disabled selected>-- Pilih --</option>
                                                  <?php
                                                    foreach($lemari as $lmr) {
                                                  ?>
                                                  <option value="<?= $lmr->kode_lemari?>"<?php if($arsip->kode_lemari==$lmr->kode_lemari){
                                                  echo "selected";} ?>>
                                                    <?=$lmr->nama?>
                                                  </option>
                                                  <?php
                                                    }
                                                  ?>
                                                </select>
                                            </div>
                                        </div> 
                                         <div class="col-sm-6">
                                            <div class="form-group">
                                                <label class="control-label">Rak</label>
                                                <select name="kode_rak" class="form-control">
                                                  <option disabled selected>-- Pilih --</option>
                                                  <?php
                                                    foreach($rak as $rk) {
                                                  ?>
                                                  <option value="<?= $rk->kode_rak?>"<?php if($arsip->kode_rak==$rk->kode_rak){
                                                  echo "selected";} ?>>
                                                    <?=$rk->nama?>
                                                  </option>
                                                  <?php
                                                    }
                                                  ?>
                                                </select>
                                            </div>
                                        </div> 
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label class="control-label">Kategori</label>
                                                <select name="kode" class="form-control">
                                                  <option disabled selected>-- Pilih --</option>
                                                  <?php
                                                    foreach($kategori as $ktg) {
                                                  ?>
                                                  <option value="<?= $ktg->kode?>"<?php if($arsip->kode==$ktg->kode){
                                                  echo "selected";} ?>>
                                                    <?=$ktg->nama_k?>
                                                  </option>
                                                  <?php
                                                    }
                                                  ?>
                                                </select>
                                            </div>
                                             <div class="form-group">
                                             <input class="btn btn-success" type="submit" name="btn" value="Save" />
                                            </div>
                                        </div> 
                                    </div>    
                                    </div>
                                    
                                </div>
                               
                            </section>
                        </div>
                    </div>
                    </form>
                  <!-- end: page -->
                </section>
            </div>
    </section>
   <script src="<?php echo base_url('assets/vendor/jquery/jquery.js')?>"></script>
        <script src="<?php echo base_url('assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js')?>"></script>
        <script src="<?php echo base_url('assets/vendor/bootstrap/js/bootstrap.js')?>"></script>
        <script src="<?php echo base_url('assets/vendor/nanoscroller/nanoscroller.js')?>"></script>
        <script src="<?php echo base_url('assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js')?>"></script>
        <script src="<?php echo base_url('assets/vendor/magnific-popup/magnific-popup.js')?>"></script>
        <script src="<?php echo base_url('assets/vendor/jquery-placeholder/jquery.placeholder.js')?>"></script>
        <!-- Specific Page Vendor -->
        <script src="<?php echo base_url('assets/vendor/select2/select2.js')?>"></script>
        <script src="<?php echo base_url('assets/vendor/jquery-datatables/media/js/jquery.dataTables.js')?>"></script>
        <script src="<?php echo base_url('assets/vendor/jquery-datatables-bs3/assets/js/datatables.js')?>"></script>
        <!-- Theme Base, Components and Settings -->
        <script src="<?php echo base_url('assets/javascripts/theme.js')?>"></script>
        <!-- Theme Custom -->
        <script src="<?php echo base_url('assets/javascripts/theme.custom.js')?>"></script>
        <!-- Theme Initialization Files -->
        <script src="<?php echo base_url('assets/javascripts/theme.init.js')?>"></script>
        <!-- Examples -->
        <script src="<?php echo base_url('assets/javascripts/tables/examples.datatables.editable.js')?>"></script>
</body>
</html>
