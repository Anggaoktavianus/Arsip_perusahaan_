

<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- Basic -->
        <meta charset="UTF-8">

        <title>Tambah Dokumen</title>
        <meta name="keywords" content="HTML5 Admin Template" />
        <meta name="description" content="Porto Admin - Responsive HTML5 Template">
        <meta name="author" content="okler.net">

        <!-- Mobile Metas -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

        <!-- Web Fonts  -->
        <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

        <!-- Vendor CSS -->
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/bootstrap/css/bootstrap.css')?>" />
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/font-awesome/css/font-awesome.css')?>" />
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/magnific-popup/magnific-popup.css')?>" />
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/bootstrap-datepicker/css/datepicker3.css')?>" />
        <!-- Specific Page Vendor CSS -->
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/select2/select2.css')?>" />
        <link rel="stylesheet" href="<?php echo base_url('assets/vendor/jquery-datatables-bs3/assets/css/datatables.css')?>" />
        <!-- Theme CSS -->
        <link rel="stylesheet" href="<?php echo base_url('assets/stylesheets/theme.css')?>" />
        <!-- Skin CSS -->
        <link rel="stylesheet" href="<?php echo base_url('assets/stylesheets/skins/default.css')?>" />
        <!-- Theme Custom CSS -->
        <link rel="stylesheet" href="<?php echo base_url('assets/stylesheets/theme-custom.css')?>">
        <!-- Head Libs -->
        <script src="<?php echo base_url('assets/vendor/modernizr/modernizr.js')?>"></script>
    </head>
<body>
    <section class="body">
            <!-- start: header -->
            <?php $this->load->view("admin/partials/head.php") ?>
            <!-- end: header -->
            <div class="inner-wrapper">
                <!-- start: sidebar -->
                <?php $this->load->view("admin/partials/sidebar.php") ?>
                
                <!-- end: sidebar -->
                <!-- DataTables -->
                <section role="main" class="content-body">
                    <header class="page-header">
                        <h2>Tambah Dokumen</h2>
                        <div class="right-wrapper pull-right">
                            <ol class="breadcrumbs">
                                <li>
                                    <a href="index.html">
                                        <i class="fa fa-home"></i>
                                    </a>
                                </li>
                                <li><span>Tambah</span></li>
                                <li><span>Dokumen</span></li>
                            </ol>
                            <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
                        </div>
                    </header>
                
                    <!-- start: page -->
               
                   <form method="post" enctype="multipart/form-data" action="<?php echo base_url(); ?>admin/arsip/aksi_tambah">
                    <div class="row">
                    <?php if (validation_errors()):?>
                        <div class="alert alert-success alert-dismissible"><?= validation_errors(); ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                        </div>
                    <?php endif;?>
                        <div class="col-md-12">
                            <section class="panel">
                                <header class="panel-heading">
                                    <div class="panel-actions">
                                        <a href="#" class="fa fa-caret-down"></a>
                                        <a href="#" class="fa fa-times"></a>
                                    </div>
                                    <h2 class="panel-title">Form Tambah</h2>
                                </header>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label class="control-label">Judul</label>
                                                <input type="text" name="judul"  class="form-control" >
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label class="control-label">Deskripsi</label>
                                                <input type="Text" name="deskripsi"  class="form-control" >
                                            </div>
                                        </div>
                                         <div class="col-sm-6">
                                            <div class="form-group">
                                                <label class="control-label">File</label>
                                                <input type="file" name="nama_file"  class="form-control" >
                                            </div>
                                        </div>  
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label class="control-label">Tanggal Dokumen</label>
                                                <input type="date" name="tgl_dokumen"  class="form-control" >
                                            </div>
                                        </div> 
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label class="control-label">Lemari</label>
                                                <select name="kode_lemari" class="form-control">
                                                  <option disabled selected>-- Pilih --</option>
                                                  <?php
                                                    foreach($lemari as $lmr) {
                                                  ?>
                                                  <option value="<?=$lmr->kode_lemari;?>"><?=$lmr->nama;?></option>
                                                  <?php
                                                    }
                                                  ?>
                                                </select>
                                            </div>
                                        </div> 
                                         <div class="col-sm-6">
                                            <div class="form-group">
                                                <label class="control-label">Rak</label>
                                                <select name="kode_rak" class="form-control">
                                                  <option disabled selected>-- Pilih --</option>
                                                  <?php
                                                    foreach($rak as $rk) {
                                                  ?>
                                                  <option value="<?=$rk->kode_rak;?>"><?=$rk->nama;?></option>
                                                  <?php
                                                    }
                                                  ?>
                                                </select>
                                            </div>
                                        </div> 
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label class="control-label">Kategori</label>
                                                <select name="kode" class="form-control">
                                                  <option disabled selected>-- Pilih --</option>
                                                  <?php
                                                    foreach($kategori as $ktg) {
                                                  ?>
                                                  <option value="<?=$ktg->kode;?>"><?=$ktg->nama_k;?></option>
                                                  <?php
                                                    }
                                                  ?>
                                                </select>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                                <footer class="panel-footer">
                                    <input class="btn btn-primary" type="submit" name="btn" value="Save" />
                                </footer>
                            </section>
                        </div>
                    </div>
                <?=form_close();?> 
                  <!-- end: page -->
                </section>
            </div>
            </div>
    </section>
     <script src="<?php echo base_url('assets/vendor/jquery/jquery.js')?>"></script>
        <script src="<?php echo base_url('assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js')?>"></script>
        <script src="<?php echo base_url('assets/vendor/bootstrap/js/bootstrap.js')?>"></script>
        <script src="<?php echo base_url('assets/vendor/nanoscroller/nanoscroller.js')?>"></script>
        <script src="<?php echo base_url('assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js')?>"></script>
        <script src="<?php echo base_url('assets/vendor/magnific-popup/magnific-popup.js')?>"></script>
        <script src="<?php echo base_url('assets/vendor/jquery-placeholder/jquery.placeholder.js')?>"></script>
        <!-- Specific Page Vendor -->
        <script src="<?php echo base_url('assets/vendor/select2/select2.js')?>"></script>
        <script src="<?php echo base_url('assets/vendor/jquery-datatables/media/js/jquery.dataTables.js')?>"></script>
        <script src="<?php echo base_url('assets/vendor/jquery-datatables-bs3/assets/js/datatables.js')?>"></script>
        <!-- Theme Base, Components and Settings -->
        <script src="<?php echo base_url('assets/javascripts/theme.js')?>"></script>
        <!-- Theme Custom -->
        <script src="<?php echo base_url('assets/javascripts/theme.custom.js')?>"></script>
        <!-- Theme Initialization Files -->
        <script src="<?php echo base_url('assets/javascripts/theme.init.js')?>"></script>
        <!-- Examples -->
        <script src="<?php echo base_url('assets/javascripts/tables/examples.datatables.editable.js')?>"></script>
</body>
</html>
