      <div class="footer-copyright-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="footer-copy-right">
                            <p> Copyright &copy; Ezra Pratama <a href="https://colorlib.com/wp/templates/"></a> </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>