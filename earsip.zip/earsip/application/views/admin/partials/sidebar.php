            <aside id="sidebar-left" class="sidebar-left">
                
                    <div class="sidebar-header">
                        <div class="sidebar-title">
                            Navigation
                        </div>
                        <div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
                            <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
                        </div>
                    </div>
                
                    <div class="nano">
                        <div class="nano-content">
                            <nav id="menu" class="nav-main" role="navigation">
                                <ul class="nav nav-main">
                                    <li class="nav-active">
                                        <a href="<?php echo site_url('admin') ?>">
                                            <i class="fa fa-home" aria-hidden="true"></i>
                                            <span>Dashboard </span>
                                        </a>
                                    </li>
                                    <li class="nav-parent">
                                        <a>
                                            <i class="fa fa-gear" aria-hidden="true"></i>
                                            <span>Data Master</span>
                                        </a>
                                        <ul class="nav nav-children">
                                            <li>
                                                <a href="<?php echo site_url('admin/master/') ?>">
                                                     User
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo site_url('admin/kategori/') ?>">
                                                     Kategori
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo site_url('admin/rak/')?>">
                                                     Rak
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo site_url('admin/lemari/')?>">
                                                    Lemari
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="nav-main">
                                        <a  href="<?php echo site_url('admin/arsip/')?>"">
                                            <i class="fa fa-list-alt" aria-hidden="true"></i>
                                            <span>Dokumen</span>
                                        </a>
                                    </li>
                                </ul>
                            </nav>
   
                            <hr class="separator" />
                
                            <div class="sidebar-widget widget-stats">
                                <div class="widget-header">
                                    <h6>Company Stats</h6>
                                    <div class="widget-toggle">+</div>
                                </div>
                                <div class="widget-content">
                                    
                                </div>
                            </div>
                        </div>
                
                    </div>
                
                </aside>